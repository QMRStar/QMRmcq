import { Logo } from "./Logo";
export function Nav() {
  return <nav className="mx-auto flex max-w-6xl items-center justify-between px-5 py-6">
    <Logo />
    <div className="flex gap-2">
      <a className="btn-secondary" href="/pricing">Pricing</a>
      <a className="btn-primary" href="/dashboard">Dashboard</a>
    </div>
  </nav>;
}
