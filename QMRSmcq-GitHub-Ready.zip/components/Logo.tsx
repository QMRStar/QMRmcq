export function Logo() {
  return <a href="/" className="text-xl font-extrabold tracking-tight">QMR<span className="gradient-text">Smcq</span></a>;
}
