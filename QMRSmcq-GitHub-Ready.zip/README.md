# QMRSmcq V1

A full-stack, source-grounded medical MCQ platform.

## What is included

- Modern Apple-inspired glass UI
- Email/password authentication
- PostgreSQL + Prisma
- Secure HTTP-only session cookie
- 5 free generations per user
- Monthly ($5) and yearly ($20) manual activation
- Activation-code system
- Admin dashboard for creating codes and managing users
- PDF/DOCX/TXT/PPTX text extraction
- Source-grounded AI MCQ generation
- Exactly 10/20/30/40/50 questions
- Duplicate/near-duplicate filtering
- Validation pass for answer consistency and source grounding
- Interactive exam mode
- Immediate correct/incorrect feedback
- Explanation after wrong answers
- Source/page metadata
- Saved exam history
- Results and review page
- Export exam as JSON
- Rate limiting
- Server-side subscription and attempt checks

## Requirements

- Node.js 20+
- PostgreSQL 15+
- OpenAI API key

## Local setup

1. Create a PostgreSQL database.
2. Copy `.env.example` to `.env`.
3. Fill in `DATABASE_URL`, `OPENAI_API_KEY`, `SESSION_SECRET`, and `ADMIN_EMAIL`.
4. Install dependencies:

   npm install

5. Create the database schema:

   npx prisma generate
   npx prisma db push

6. Start:

   npm run dev

Open http://localhost:3000

## First admin

The admin account is the account whose email exactly matches `ADMIN_EMAIL`.
Create that account through `/register`.

## Important production notes

- Put the app behind HTTPS.
- Use a managed PostgreSQL database.
- Store uploaded files in object storage instead of local disk if deployed on serverless infrastructure.
- Add an email verification/reset-password provider before public launch.
- Set strict upload size limits and malware scanning for untrusted uploads.
- Keep `OPENAI_API_KEY` server-side only.
- Configure a production `SESSION_SECRET`.
- Review AI-generated questions before using them as official examination material.

## Manual subscriptions

The initial business model intentionally does not process card payments inside the site.

Student:
1. Chooses Monthly or Yearly.
2. Contacts Telegram @ID29i.
3. Receives an activation code.
4. Opens `/activate`.
5. Enters the code.
6. The server creates the subscription.

Admin:
1. Opens `/admin`.
2. Generates codes.
3. Chooses Monthly / Yearly / Custom.
4. Sends the code to the student.

## AI behavior

The generation prompt explicitly requires:
- source material only
- one correct option
- concise university medical-exam style
- no repeated concept
- explanation
- source/page reference when available

The server then performs deterministic validation and a second AI validation pass.
