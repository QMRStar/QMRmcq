import {NextResponse} from "next/server";
import {getCurrentUser} from "@/lib/auth";
import {db} from "@/lib/db";
export async function POST(req:Request,{params}:{params:Promise<{id:string}>}){
 const user=await getCurrentUser(); if(!user)return NextResponse.json({error:"Unauthorized"},{status:401});
 const {id}=await params; const exam=await db.exam.findFirst({where:{id,userId:user.id},include:{questions:true}});
 if(!exam)return NextResponse.json({error:"Not found"},{status:404});
 const body=await req.json() as {answers:Record<string,number>};
 const score=exam.questions.reduce((n,q)=>n+(body.answers?.[q.id]===q.correctIndex?1:0),0);
 await db.exam.update({where:{id},data:{status:"COMPLETED",score,completedAt:new Date()}});
 return NextResponse.json({score});
}
