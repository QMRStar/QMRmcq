import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { hasActiveSubscription, consumeFreeAttempt } from "@/lib/limits";
import { extractText } from "@/lib/extract";
import { generateExam } from "@/lib/ai";
import { db } from "@/lib/db";
import { rateLimit } from "@/lib/rate-limit";

export const runtime = "nodejs";

const MAX_MB = Number(process.env.MAX_UPLOAD_MB || 20);
const schema = z.object({ specialty: z.string().min(2).max(40), count: z.coerce.number().refine(n=>[10,20,30,40,50].includes(n)) });

export async function POST(req: Request) {
  try {
    const user = await requireUser();
    if (!(await rateLimit(`generate:${user.id}`, 5, 30))) return NextResponse.json({error:"Too many generation requests. Please try again later."},{status:429});
    const form = await req.formData();
    const file = form.get("file");
    const parsed = schema.parse({specialty: form.get("specialty"), count: form.get("count")});
    if (!(file instanceof File)) return NextResponse.json({error:"Please upload a file."},{status:400});
    if (file.size > MAX_MB * 1024 * 1024) return NextResponse.json({error:`File exceeds ${MAX_MB} MB.`},{status:400});
    const allowed = [".pdf",".docx",".txt",".pptx"];
    if (!allowed.some(x=>file.name.toLowerCase().endsWith(x))) return NextResponse.json({error:"Unsupported file type."},{status:400});

    const premium = await hasActiveSubscription(user.id);
    if (!premium) {
      const consumed = await consumeFreeAttempt(user.id);
      if (!consumed) return NextResponse.json({error:"You have used all 5 free attempts. Please activate Premium."},{status:402});
    }

    const text = await extractText(file);
    if (text.length < 100) return NextResponse.json({error:"The file did not contain enough readable text."},{status:400});
    const limitedText = text.slice(0, 180000);
    const result = await generateExam(limitedText, parsed.count, parsed.specialty);

    const savedFile = await db.studyFile.create({data:{userId:user.id,name:file.name,mimeType:file.type||"application/octet-stream",text:limitedText}});
    const exam = await db.exam.create({
      data:{userId:user.id,fileId:savedFile.id,title:result.title,specialty:parsed.specialty,questionCount:result.questions.length,
        questions:{create:result.questions.map(q=>({stem:q.stem,options:q.options,correctIndex:q.correctIndex,explanation:q.explanation,source:q.source,sourcePage:q.sourcePage}))}}
    });
    return NextResponse.json({examId:exam.id});
  } catch (e) {
    console.error(e);
    return NextResponse.json({error:"Generation failed. Check the file and server configuration."},{status:500});
  }
}
