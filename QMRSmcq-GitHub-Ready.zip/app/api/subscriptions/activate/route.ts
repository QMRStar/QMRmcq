import {NextResponse} from "next/server";
import {z} from "zod";
import {getCurrentUser} from "@/lib/auth";
import {db} from "@/lib/db";
const body=z.object({code:z.string().min(6).max(50)});
export async function POST(req:Request){
 const user=await getCurrentUser();if(!user)return NextResponse.json({error:"Unauthorized"},{status:401});
 const {code}=body.parse(await req.json());
 const activation=await db.activationCode.findUnique({where:{code}});
 if(!activation||activation.used)return NextResponse.json({error:"Invalid or already used activation code."},{status:400});
 const start=new Date(); const expires=new Date(start); expires.setDate(expires.getDate()+activation.durationDays);
 await db.$transaction([
   db.activationCode.update({where:{id:activation.id},data:{used:true,usedById:user.id,usedAt:new Date()}}),
   db.subscription.create({data:{userId:user.id,plan:activation.plan,status:"ACTIVE",startsAt:start,expiresAt:expires,activationCode:activation.code}})
 ]);
 return NextResponse.json({message:`Premium activated until ${expires.toLocaleDateString()}.`});
}
