import {NextResponse} from "next/server";
import {isAdmin} from "@/lib/auth";
import {db} from "@/lib/db";
function makeCode(){const alphabet="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";let s="QMR";for(let block=0;block<2;block++){s+="-";for(let i=0;i<4;i++)s+=alphabet[Math.floor(Math.random()*alphabet.length)]}return s}
export async function POST(req:Request){if(!(await isAdmin()))return NextResponse.json({error:"Forbidden"},{status:403});const b=await req.json();const quantity=Math.min(100,Math.max(1,Number(b.quantity||1)));const plan=["MONTHLY","YEARLY","CUSTOM"].includes(b.plan)?b.plan:"MONTHLY";const durationDays=Math.max(1,Number(b.durationDays||30));const codes:string[]=[];for(let i=0;i<quantity;i++){let code=makeCode();while(await db.activationCode.findUnique({where:{code}}))code=makeCode();await db.activationCode.create({data:{code,plan,durationDays}});codes.push(code)}return NextResponse.json({codes})}
