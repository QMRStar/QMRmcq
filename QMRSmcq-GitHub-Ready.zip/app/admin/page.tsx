import {redirect} from "next/navigation";
import {isAdmin} from "@/lib/auth";
import {db} from "@/lib/db";
import AdminClient from "./ui";
export default async function Admin(){if(!(await isAdmin()))redirect("/");const users=await db.user.count();const exams=await db.exam.count();const active=await db.subscription.count({where:{status:"ACTIVE",expiresAt:{gt:new Date()}}});return <main className="min-h-screen px-5 py-10"><div className="mx-auto max-w-6xl"><div className="flex justify-between"><a href="/" className="font-extrabold">QMR<span className="gradient-text">Smcq</span></a><span className="rounded-full bg-white/70 px-4 py-2 text-sm">Admin</span></div><div className="mt-10 grid gap-4 md:grid-cols-3">{[[users,"Users"],[active,"Active Premium"],[exams,"Exams"]].map(([n,t])=><div className="card" key={String(t)}><p className="text-sm text-slate-500">{t}</p><p className="mt-2 text-4xl font-bold">{n}</p></div>)}</div><AdminClient/></div></main>}
