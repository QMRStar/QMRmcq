import { Nav } from "@/components/Nav";

export default function Home() {
  return <main className="min-h-screen overflow-hidden">
    <Nav />
    <section className="mx-auto grid max-w-6xl gap-12 px-5 pb-20 pt-14 lg:grid-cols-2 lg:items-center">
      <div>
        <span className="rounded-full border border-white bg-white/60 px-4 py-2 text-sm font-semibold text-slate-600 shadow-sm">Medical • AI • Source-grounded</span>
        <h1 className="mt-7 text-5xl font-bold leading-[1.05] tracking-tight md:text-7xl">Turn your study files into <span className="gradient-text">exam-ready MCQs.</span></h1>
        <p className="mt-6 max-w-xl text-lg leading-8 text-slate-600">Generate concise medical-university style questions strictly from your uploaded material, with explanations, sources and duplicate protection.</p>
        <div className="mt-8 flex flex-wrap gap-3">
          <a href="/register" className="btn-primary">Start for free →</a>
          <a href="/pricing" className="btn-secondary">View plans</a>
        </div>
        <p className="mt-5 text-sm text-slate-500">5 free attempts • 10–50 questions • Pharmacy, Medicine & Dentistry</p>
      </div>
      <div className="card">
        <div className="rounded-3xl bg-white/80 p-6">
          <div className="flex justify-between text-sm text-slate-500"><span>Question 8 / 20</span><span>40%</span></div>
          <div className="mt-3 h-2 rounded-full bg-slate-100"><div className="h-2 w-2/5 rounded-full bg-gradient-to-r from-blue-500 to-violet-500"/></div>
          <h2 className="mt-7 text-xl font-bold">Which statement is supported by the uploaded lecture?</h2>
          <div className="mt-5 grid gap-3">{["A. First statement","B. Second statement","C. Third statement","D. Fourth statement"].map((x,i)=><div key={x} className={`rounded-2xl border p-4 ${i===1?"border-indigo-300 bg-indigo-50":"border-slate-100 bg-white"}`}>{x}</div>)}</div>
          <div className="mt-5 rounded-2xl bg-emerald-50 p-4 text-sm text-emerald-800">✓ Correct — explanation and source are shown after answering.</div>
        </div>
      </div>
    </section>
    <section className="mx-auto grid max-w-6xl gap-4 px-5 pb-20 md:grid-cols-3">
      {[
        ["01","Upload","PDF, DOCX, TXT and PPTX."],
        ["02","Generate","10–50 source-grounded questions."],
        ["03","Review","Instant feedback, explanations and sources."]
      ].map(([n,t,d])=><div className="card" key={n}><span className="text-sm font-bold text-indigo-500">{n}</span><h3 className="mt-4 text-xl font-bold">{t}</h3><p className="mt-2 text-slate-500">{d}</p></div>)}
    </section>
  </main>;
}
