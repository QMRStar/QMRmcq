'use client';
import { useState } from "react";
import { useRouter } from "next/navigation";
import { logout } from "@/app/actions/auth";

export function LogoutButton(){return <form action={logout}><button className="btn-secondary">Sign out</button></form>}

export function GenerateForm({premium}:{premium:boolean}){
 const [file,setFile]=useState<File|null>(null),[specialty,setSpecialty]=useState("Pharmacy"),[count,setCount]=useState(20),[busy,setBusy]=useState(false),[error,setError]=useState("");
 const router=useRouter();
 async function submit(){
  if(!file)return;
  setBusy(true);setError("");
  const fd=new FormData();fd.append("file",file);fd.append("specialty",specialty);fd.append("count",String(count));
  const res=await fetch("/api/exams/generate",{method:"POST",body:fd});
  const data=await res.json();
  if(!res.ok){setError(data.error||"Generation failed.");setBusy(false);return;}
  router.push(`/exam/${data.examId}`);
 }
 return <div className="grid gap-5 lg:grid-cols-2">
   <label className="card cursor-pointer text-center"><input className="hidden" type="file" accept=".pdf,.docx,.txt,.pptx" onChange={e=>setFile(e.target.files?.[0]||null)}/><div className="text-5xl">📄</div><h2 className="mt-4 text-xl font-bold">{file?file.name:"Upload study material"}</h2><p className="mt-2 text-sm text-slate-500">PDF, DOCX, TXT or PPTX • max 20 MB</p></label>
   <div className="card"><label className="text-sm font-bold">Specialty<select className="input mt-2" value={specialty} onChange={e=>setSpecialty(e.target.value)}><option>Pharmacy</option><option>Medicine</option><option>Dentistry</option><option>Other</option></select></label>
   <p className="mt-6 text-sm font-bold">Questions</p><div className="mt-2 grid grid-cols-5 gap-2">{[10,20,30,40,50].map(n=><button type="button" key={n} onClick={()=>setCount(n)} className={`rounded-xl p-3 ${count===n?"bg-indigo-500 text-white":"bg-white"}`}>{n}</button>)}</div>
   <button disabled={!file||busy} onClick={submit} className="btn-primary mt-7 w-full disabled:opacity-40">{busy?"Analyzing & generating…":`Generate ${count} MCQs`}</button>
   {error&&<p className="mt-4 rounded-2xl bg-red-50 p-3 text-sm text-red-700">{error}</p>}
   {!premium&&<p className="mt-4 text-xs text-slate-400">Generation consumes one free attempt. Premium users are unlimited while their subscription is active.</p>}</div>
 </div>;
}
