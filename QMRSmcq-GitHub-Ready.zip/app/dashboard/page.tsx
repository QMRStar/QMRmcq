import { redirect } from "next/navigation";
import { getCurrentUser, hasActiveSubscription } from "@/lib/combined";
import { LogoutButton, GenerateForm } from "./ui";

export default async function Dashboard() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const premium = await hasActiveSubscription(user.id);
  return <main className="min-h-screen px-5 py-8"><div className="mx-auto max-w-6xl">
    <header className="flex flex-wrap items-center justify-between gap-4"><a href="/" className="text-xl font-extrabold">QMR<span className="gradient-text">Smcq</span></a><div className="flex items-center gap-2"><a href="/pricing" className="btn-secondary">Pricing</a><a href="/activate" className="btn-secondary">Activate</a><LogoutButton/></div></header>
    <section className="mt-12"><p className="text-sm font-bold text-indigo-500">DASHBOARD</p><h1 className="mt-2 text-4xl font-bold">Create your next exam.</h1><p className="mt-3 text-slate-500">{premium ? "Premium active — unlimited generations." : `Free attempts used: ${user.freeAttemptsUsed} / 5`}</p><div className="mt-8"><GenerateForm premium={premium}/></div></section>
  </div></main>;
}