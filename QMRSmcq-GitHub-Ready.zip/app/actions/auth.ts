'use server';
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { createSession, hashPassword, verifyPassword, destroySession } from "@/lib/auth";

export async function register(formData: FormData) {
  const email = String(formData.get("email") || "").trim().toLowerCase();
  const password = String(formData.get("password") || "");
  if (!email || password.length < 8) redirect("/register?error=invalid");
  const exists = await db.user.findUnique({ where: { email } });
  if (exists) redirect("/login?error=exists");
  const user = await db.user.create({ data: { email, passwordHash: await hashPassword(password) } });
  await createSession(user.id);
  redirect("/dashboard");
}

export async function login(formData: FormData) {
  const email = String(formData.get("email") || "").trim().toLowerCase();
  const password = String(formData.get("password") || "");
  const user = await db.user.findUnique({ where: { email } });
  if (!user || !(await verifyPassword(password, user.passwordHash))) redirect("/login?error=invalid");
  await createSession(user.id);
  redirect("/dashboard");
}

export async function logout() {
  await destroySession();
  redirect("/");
}
