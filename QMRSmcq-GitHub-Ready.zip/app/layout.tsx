import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "QMRSmcq",
  description: "Source-grounded medical MCQ generator",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
