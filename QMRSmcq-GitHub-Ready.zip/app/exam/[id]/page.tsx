import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import ExamClient from "./ui";

export default async function ExamPage({params}:{params:Promise<{id:string}>}){
 const user=await getCurrentUser(); if(!user)redirect("/login");
 const {id}=await params;
 const exam=await db.exam.findFirst({where:{id,userId:user.id},include:{questions:true}});
 if(!exam)redirect("/dashboard");
 const questions=exam.questions.map(q=>({id:q.id,stem:q.stem,options:q.options as string[],explanation:q.explanation,source:q.source,sourcePage:q.sourcePage,correctIndex:q.correctIndex}));
 return <ExamClient exam={{id:exam.id,title:exam.title,questions}}/>;
}
