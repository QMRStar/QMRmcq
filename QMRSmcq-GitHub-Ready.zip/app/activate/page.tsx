import {redirect} from "next/navigation";
import {getCurrentUser} from "@/lib/auth";
import ActivateForm from "./ui";
export default async function Activate(){const user=await getCurrentUser();if(!user)redirect("/login");return <main className="min-h-screen grid place-items-center px-5"><div className="card w-full max-w-md"><a href="/" className="font-bold">QMR<span className="gradient-text">Smcq</span></a><h1 className="mt-10 text-3xl font-bold">Activate Premium</h1><p className="mt-3 text-slate-500">Enter the code you received from QMRSmcq.</p><ActivateForm/><p className="mt-5 text-center text-sm text-slate-500">Need a code? <a className="text-indigo-500" href="https://t.me/ID29i">@ID29i</a></p></div></main>}
