# QMRSmcq GitHub Upload

Upload the contents of this folder to the root of your GitHub repository.
Do not upload .env, node_modules, or .next.
.env.example is safe because it contains placeholders only.
