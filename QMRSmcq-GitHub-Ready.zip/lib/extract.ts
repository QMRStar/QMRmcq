import pdfParse from "pdf-parse";
import mammoth from "mammoth";
import JSZip from "jszip";

function clean(text: string) {
  return text.replace(/\r/g, "").replace(/[ \t]+/g, " ").replace(/\n{3,}/g, "\n\n").trim();
}

async function extractPptx(buffer: Buffer) {
  const zip = await JSZip.loadAsync(buffer);
  const slides = Object.keys(zip.files).filter(x => /^ppt\/slides\/slide\d+\.xml$/.test(x)).sort((a,b) => {
    const n = (x:string) => Number(x.match(/slide(\d+)/)?.[1] || 0);
    return n(a) - n(b);
  });
  const chunks: string[] = [];
  for (let i = 0; i < slides.length; i++) {
    const xml = await zip.files[slides[i]].async("string");
    const text = [...xml.matchAll(/<a:t>(.*?)<\/a:t>/g)].map(m => m[1]).join(" ");
    if (text.trim()) chunks.push(`[Slide ${i + 1}] ${text}`);
  }
  return chunks.join("\n\n");
}

export async function extractText(file: File) {
  const buffer = Buffer.from(await file.arrayBuffer());
  const name = file.name.toLowerCase();
  if (name.endsWith(".pdf")) return clean((await pdfParse(buffer)).text);
  if (name.endsWith(".docx")) return clean((await mammoth.extractRawText({ buffer })).value);
  if (name.endsWith(".pptx")) return clean(await extractPptx(buffer));
  if (name.endsWith(".txt")) return clean(buffer.toString("utf8"));
  throw new Error("UNSUPPORTED_FILE");
}
