import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
import bcrypt from "bcryptjs";
import { db } from "./db";

const secret = new TextEncoder().encode(process.env.SESSION_SECRET || "development-only-secret-change-me");

export async function hashPassword(password: string) {
  return bcrypt.hash(password, 12);
}

export async function verifyPassword(password: string, hash: string) {
  return bcrypt.compare(password, hash);
}

export async function createSession(userId: string) {
  const token = await new SignJWT({ userId })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("30d")
    .sign(secret);

  const jar = await cookies();
  jar.set("qmrsmcq_session", token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 30,
  });
}

export async function destroySession() {
  const jar = await cookies();
  jar.set("qmrsmcq_session", "", { httpOnly: true, expires: new Date(0), path: "/" });
}

export async function getCurrentUser() {
  const jar = await cookies();
  const token = jar.get("qmrsmcq_session")?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret);
    const userId = String(payload.userId);
    return db.user.findUnique({ where: { id: userId } });
  } catch {
    return null;
  }
}

export async function requireUser() {
  const user = await getCurrentUser();
  if (!user) throw new Error("UNAUTHORIZED");
  return user;
}

export async function isAdmin() {
  const user = await getCurrentUser();
  return !!user && user.email.toLowerCase() === (process.env.ADMIN_EMAIL || "").toLowerCase();
}
