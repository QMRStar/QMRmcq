import { db } from "./db";

export async function hasActiveSubscription(userId: string) {
  const now = new Date();
  const sub = await db.subscription.findFirst({
    where: { userId, status: "ACTIVE", expiresAt: { gt: now } },
    orderBy: { expiresAt: "desc" },
  });
  return !!sub;
}

export async function consumeFreeAttempt(userId: string) {
  const result = await db.user.updateMany({
    where: { id: userId, freeAttemptsUsed: { lt: 5 } },
    data: { freeAttemptsUsed: { increment: 1 } },
  });
  return result.count === 1;
}
