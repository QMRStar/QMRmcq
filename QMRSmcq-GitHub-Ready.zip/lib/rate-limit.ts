import { db } from "./db";

export async function rateLimit(key: string, max = 10, windowMinutes = 10) {
  const now = new Date();
  const window = new Date(Math.floor(now.getTime() / (windowMinutes * 60_000)) * windowMinutes * 60_000);
  const existing = await db.rateLimit.findUnique({ where: { key_window: { key, window } } });
  if (!existing) {
    await db.rateLimit.create({ data: { key, window, count: 1 } });
    return true;
  }
  if (existing.count >= max) return false;
  await db.rateLimit.update({ where: { id: existing.id }, data: { count: { increment: 1 } } });
  return true;
}
