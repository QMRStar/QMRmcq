import OpenAI from "openai";
import { z } from "zod";

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const model = process.env.OPENAI_MODEL || "gpt-5.6";

const QuestionSchema = z.object({
  stem: z.string().min(5),
  options: z.array(z.string().min(1)).length(4),
  correctIndex: z.number().int().min(0).max(3),
  explanation: z.string().min(3),
  source: z.string().min(1),
  sourcePage: z.number().int().positive().nullable(),
});

const OutputSchema = z.object({ title: z.string(), questions: z.array(QuestionSchema) });

function normalize(s: string) {
  return s.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim();
}

function dedupe(items: z.infer<typeof QuestionSchema>[]) {
  const seen = new Set<string>();
  return items.filter(q => {
    const key = normalize(q.stem);
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

async function generateBatch(source: string, count: number, specialty: string) {
  const prompt = `You are QMRSmcq, a strict medical university examination generator.

SOURCE MATERIAL:
${source}

RULES:
1. Use ONLY information explicitly supported by SOURCE MATERIAL. Never add outside facts.
2. Generate exactly ${count} MCQs for ${specialty}.
3. Questions must be concise and resemble rigorous university medical exam questions.
4. Exactly one option is correct.
5. Distractors must be plausible but not also correct according to the source.
6. Do not repeat a question or repeat the same tested concept with different wording.
7. Give a short explanation. If the answer is wrong, the explanation must clearly state why the correct option is correct.
8. Include a source quote/location description; if a page number is identifiable, include sourcePage.
9. Never invent a page number.
10. If the source does not contain enough information for a valid question, skip that concept.
11. Avoid "all of the above", "none of the above", and trivia.
12. Return JSON only in the requested schema.`;

  const response = await client.responses.create({
    model,
    input: prompt,
    text: {
      format: {
        type: "json_schema",
        name: "qmrsmcq_exam",
        strict: true,
        schema: {
          type: "object",
          additionalProperties: false,
          properties: {
            title: { type: "string" },
            questions: {
              type: "array",
              items: {
                type: "object",
                additionalProperties: false,
                properties: {
                  stem: { type: "string" },
                  options: { type: "array", items: { type: "string" }, minItems: 4, maxItems: 4 },
                  correctIndex: { type: "integer" },
                  explanation: { type: "string" },
                  source: { type: "string" },
                  sourcePage: { type: ["integer", "null"] }
                },
                required: ["stem","options","correctIndex","explanation","source","sourcePage"]
              }
            }
          },
          required: ["title","questions"]
        }
      }
    }
  });

  return OutputSchema.parse(JSON.parse(response.output_text));
}

export async function generateExam(source: string, count: number, specialty: string) {
  const chunks: z.infer<typeof QuestionSchema>[] = [];
  let title = `${specialty} Medical MCQ`;
  let attempts = 0;

  while (chunks.length < count && attempts < 4) {
    attempts++;
    const remaining = count - chunks.length;
    const batch = await generateBatch(source, Math.min(remaining + 5, 20), specialty);
    title = batch.title || title;
    chunks.push(...batch.questions);
    const unique = dedupe(chunks);
    chunks.length = 0;
    chunks.push(...unique);
  }

  if (chunks.length < count) throw new Error("INSUFFICIENT_UNIQUE_QUESTIONS");
  return { title, questions: chunks.slice(0, count) };
}
